



class AlertSystem:
    def __init__(self):
        pass


