from observer import Observer



class FileWatcher(Observer):
    def __init__(self, observer, obs_id):
        super().__init__(observer, obs_id)





