from observable import Observable


class FileClass(Observable):
    def __init__(self):
        super().__init__()




